package ir.asaleseyyedbaba.app

import android.content.Context
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Product(var id:Int,var name:String,var price:String,var category:String,var description:String,var image:String="")

class Store(private val c:Context){
    private val file=File(c.filesDir,"products.json")
    fun load():MutableList<Product>{
        if(!file.exists()) c.assets.open("products.json").use { input-> file.outputStream().use{ input.copyTo(it)}}
        val a=JSONArray(file.readText())
        return MutableList(a.length()){i-> val o=a.getJSONObject(i); Product(o.optInt("id"),o.optString("name"),o.optString("salePrice").ifBlank{o.optString("price")},o.optString("category"),o.optString("description"),o.optString("image"))}
    }
    fun save(list:List<Product>){
        val a=JSONArray()
        list.forEach{p->a.put(JSONObject().put("id",p.id).put("name",p.name).put("price",p.price).put("category",p.category).put("description",p.description).put("image",p.image))}
        file.writeText(a.toString())
    }
}

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{ App(Store(this)) }}
}

@Composable fun App(store:Store){
 var products by remember{ mutableStateOf(store.load()) }
 var q by remember{ mutableStateOf("") }
 var editing by remember{ mutableStateOf<Product?>(null) }
 var add by remember{ mutableStateOf(false) }
 val gold=Color(0xFFC68A16); val cream=Color(0xFFFFF8E7); val brown=Color(0xFF402B18)
 MaterialTheme(colorScheme=lightColorScheme(primary=gold,background=cream,onBackground=brown)){
  Scaffold(containerColor=cream,floatingActionButton={FloatingActionButton(onClick={add=true},containerColor=gold){Text("+",fontSize=28.sp)}}){pad->
   Column(Modifier.padding(pad).padding(16.dp)){
    Text("🍯 عسل سید بابا",fontSize=28.sp,fontWeight=FontWeight.Bold,color=brown)
    Text("عسل، عطاری و محصولات طبیعی",color=Color.Gray)
    Spacer(Modifier.height(14.dp))
    OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("جست‌وجوی محصول")},singleLine=true,shape=RoundedCornerShape(18.dp))
    Spacer(Modifier.height(12.dp))
    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
     items(products.filter{it.name.contains(q,true)||it.category.contains(q,true)}){p->
      Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
       Column(Modifier.padding(16.dp)){
        Text(p.name,fontSize=18.sp,fontWeight=FontWeight.Bold,color=brown)
        if(p.category.isNotBlank()) Text(p.category,fontSize=12.sp,color=Color.Gray)
        Spacer(Modifier.height(8.dp))
        Text(if(p.price.isBlank()) "قیمت ثبت نشده" else "${p.price} تومان",fontSize=17.sp,fontWeight=FontWeight.Bold,color=gold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){
         TextButton(onClick={editing=p.copy()}){Text("ویرایش")}
         TextButton(onClick={products=products.filter{it.id!=p.id}.toMutableList();store.save(products)}){Text("حذف",color=Color(0xFFB3261E))}
        }
       }
      }
     }
    }
   }
  }
  if(add||editing!=null){
   val base=editing ?: Product((products.maxOfOrNull{it.id}?:0)+1,"","","","","")
   EditDialog(base,onClose={add=false;editing=null}){p->
    val list=products.toMutableList(); val ix=list.indexOfFirst{it.id==p.id}; if(ix>=0)list[ix]=p else list.add(0,p)
    products=list; store.save(products); add=false;editing=null
   }
  }
 }
}

@Composable fun EditDialog(initial:Product,onClose:()->Unit,onSave:(Product)->Unit){
 var name by remember{ mutableStateOf(initial.name)}; var price by remember{mutableStateOf(initial.price)}
 var cat by remember{mutableStateOf(initial.category)}; var desc by remember{mutableStateOf(initial.description)}; var imageUri by remember{mutableStateOf(initial.image)}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u:Uri?-> if(u!=null) imageUri=u.toString()}
 AlertDialog(onDismissRequest=onClose,title={Text(if(initial.name.isBlank())"افزودن محصول" else "ویرایش محصول")},
 text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){
  OutlinedTextField(name,{name=it},label={Text("نام محصول")})
  OutlinedTextField(price,{price=it},label={Text("قیمت (تومان)")})
  OutlinedTextField(cat,{cat=it},label={Text("دسته‌بندی")})
  OutlinedTextField(desc,{desc=it},label={Text("توضیحات")})
  OutlinedButton(onClick={picker.launch("image/*")}){Text(if(imageUri.isBlank()) "انتخاب عکس از گالری" else "تغییر عکس محصول")}
 }},confirmButton={Button(onClick={if(name.isNotBlank())onSave(Product(initial.id,name,price,cat,desc,imageUri))}){Text("ذخیره")}},
 dismissButton={TextButton(onClick=onClose){Text("انصراف")}})
}